'A' %>% library
'B' %>% library()
'C' %>% library(.)

